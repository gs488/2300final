<footer>
  <p id="footer">Copyright @ 2018 Cayuga Strength and Conditioning</p>
</footer>
